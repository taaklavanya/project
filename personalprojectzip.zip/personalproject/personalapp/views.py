from django.shortcuts import render,HttpResponse
from .models import*
# Create your views here.
def home(request):
    return render(request,"home.html")

def about(request):
    return render(request,"about.html")

def portfolio(request):
    return render(request,"portfolio.html")

def contact(request):
    if request.method== 'POST':
        name= request.POST.get('name')
        email=request.POST.get('email')
        message=request.POST.get('message')
        print(name,email,message)
        user= Contact(name=name,email=email,message=message)
        user.save()
    return render(request,"contact.html")